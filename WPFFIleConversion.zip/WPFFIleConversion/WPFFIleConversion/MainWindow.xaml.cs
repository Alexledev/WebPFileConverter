﻿using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Drawing;
using WebP.Net;
using System.Diagnostics;
using System.Windows.Forms;
using System.Collections.Concurrent;
using System.Windows.Controls.Primitives;

namespace WPFFIleConversion
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    ///

    public partial class MainWindow : Window
    {
        public MainWindow()
        {            
            InitializeComponent();
        }       
    }
}